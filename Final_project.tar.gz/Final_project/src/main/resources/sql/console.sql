create database ThigmaSmartLearn;

use ThigmaSmartLearn;

create table Admin(userName varchar(20)primary key,password varchar(10),email varchar(30),type varchar(10));

create table Student(stuId varchar(10)primary key,name varchar(30),address varchar(40),email varchar(50),contactNo int(10),gender varchar(10),dateOfBirth date);

create table Parent(parentId varchar(10)primary key,name varchar(20),contactNo int(10),stuId varchar(20));



create table Registration(regId varchar(10)primary key,name varchar(40),email varchar(50), date date,parentId varchar(10),foreign key(parentId)references Parent(parentId)on update cascade on delete cascade,userName varchar(20),foreign key(userName)references Admin(userName)on update cascade on delete cascade);

create table Subject(subId varchar(10)primary key,name varchar(20),description varchar(50));

create table Lecturer(lectId varchar(10)primary key,name varchar(20),address varchar(50),tel int(10),NIC varchar(20),university varchar(20));

create table lecSubDetails(lectId varchar(10),foreign key(lectId)references Lecturer(lectId)on update cascade on delete cascade,lectName varchar(20),subId varchar(10),foreign key(subId)references Subject(subId)on update cascade on delete cascade,subName varchar(20));

create table Hall(hallId varchar(10)primary key,name varchar(10),availability varchar(15),capacity varchar(10));

create table Schedule(scheduleId varchar(10)primary key,description varchar(20),duration varchar(10),hallId varchar(10),foreign key(hallId)references Hall(hallId)on update cascade on delete cascade);

create table Class(classId varchar(10)primary key,grade varchar(50));

create table Classfee(classfeeId varchar(10)primary key,amount decimal(10,2),date date,status varchar(20),classId varchar(10),foreign key(classId)references Class(classId)on update cascade on delete cascade,stuId varchar(10),foreign key(stuId)references Student(stuId)on update cascade on delete cascade);

create table studentClassDetails(classId varchar(10),foreign key(classId)references Class(classId)on update cascade on delete cascade,stuId varchar(10),foreign key(stuId)references Student(stuId)on update cascade on delete cascade,subjectName varchar(20),lectName varchar(10));

create table Exams(examId varchar(10)primary key,name varchar(20),date date );

create table StudentResult(stuId varchar(10),foreign key(stuId)references Student(stuId)on update cascade on delete cascade,examId varchar(10),foreign key(examId)references Exams(examId)on update cascade on delete cascade,marks decimal(5,2));
