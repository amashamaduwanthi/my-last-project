package lk.ijse.dto.TM;

public class StudentResultTm {
}
