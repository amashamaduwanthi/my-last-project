package lk.ijse.dto.TM;

import lombok.*;

@Getter@Setter@NoArgsConstructor@AllArgsConstructor@ToString
public class ScheduleTm2 {
    private String scheduleId ;

    private String duration;
    private   String description ;
}
