package lk.ijse.dto.TM;

import lombok.*;

@ToString
@AllArgsConstructor
@Setter
@NoArgsConstructor
@Getter
public class ScheduleTm {
   private String HallName ;
   private String availability ;
  private   String capacity ;
   private String grade ;
  private   String description ;
  private   String duration ;
}
