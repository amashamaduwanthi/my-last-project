package lk.ijse.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ParentDto {
    private String parentId;
    private  String parentName;
    private int ParentContactNo;
    private  String StuId;
}
