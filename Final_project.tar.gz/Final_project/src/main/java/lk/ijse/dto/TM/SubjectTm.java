package lk.ijse.dto.TM;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SubjectTm {
    private String  lecId;
    private String lecName;
    private String  subId;
    private  String subName;

    }




