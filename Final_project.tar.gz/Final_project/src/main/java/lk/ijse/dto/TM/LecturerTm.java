package lk.ijse.dto.TM;

import lombok.*;

@Getter@Setter@NoArgsConstructor@AllArgsConstructor@ToString
public class LecturerTm {
    private String id;
    private String name;

    private  String Address;
    private int contact;

}
