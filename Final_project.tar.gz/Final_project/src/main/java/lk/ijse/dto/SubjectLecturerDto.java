package lk.ijse.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SubjectLecturerDto {
  private String  lecId;
   private String lecName;
  private String  subId;
    private  String subName;
}
