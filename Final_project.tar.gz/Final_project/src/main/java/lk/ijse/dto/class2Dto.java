package lk.ijse.dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class class2Dto {
    String id;
    String grade;

}
