package lk.ijse.dto;

public class examDto {
}
