package lk.ijse.dto.TM;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ResultTm {
    String stuId;
    String examId;
    double mark;
}
