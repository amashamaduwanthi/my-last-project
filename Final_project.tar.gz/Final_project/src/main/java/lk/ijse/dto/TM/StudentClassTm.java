package lk.ijse.dto.TM;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class StudentClassTm {
    private String stuId;
    private String classId;
    private String subName;
    private String lecName;
}
