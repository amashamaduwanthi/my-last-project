package lk.ijse.dto.TM;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClassTm {
    private String classId;
    private String grade;
}
