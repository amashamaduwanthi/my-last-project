package lk.ijse.dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor

public class classDto {
    String id;
    String description;
    String duration;

}
