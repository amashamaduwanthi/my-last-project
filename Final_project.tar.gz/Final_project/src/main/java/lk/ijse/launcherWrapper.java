package lk.ijse;

public class launcherWrapper {
    public static void main(String[] args) {
        launcher.main(args);
    }
}